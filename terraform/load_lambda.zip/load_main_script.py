

def load_main_script(event, context):
    print("Load lambda")