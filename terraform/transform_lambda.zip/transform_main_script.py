import pandas as pd
def transform_main_script(event, context):
    print('Transform lambda')

    d = {'col1': [1, 2], 'col2': [3, 4]}
    df = pd.DataFrame(data=d)

    s3_url = 's3://processed-bucket-ketts-lough-1/bucket.parquet.gzip'
    df.to_parquet(s3_url, compression='gzip')